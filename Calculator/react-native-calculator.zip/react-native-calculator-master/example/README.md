# React Native Calculator Example

Example usage of simple react native calculator and calculator input component.