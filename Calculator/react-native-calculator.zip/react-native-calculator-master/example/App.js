import App from './src/App'

Expo.registerRootComponent(App)
