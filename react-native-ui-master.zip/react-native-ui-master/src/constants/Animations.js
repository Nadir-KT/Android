export const Animations = [
  "fadeIn",
  "fadeInUp",
  "fadeInDown",
  "fadeInDownBig",
  "fadeInUpBig",
  "fadeInLeft",
  "fadeInLeftBig",
  "fadeInRight",
  "fadeInRightBig",

  "flipInX",
  "flipInY",
 
  "slideInDown",
  "slideInUp",
  "slideInLeft",
  "slideInRight",
  
  "zoomIn",
  "zoomInDown",
  "zoomInUp",
  "zoomInLeft",
  "zoomInRight",
]

export const fadeOutAnim = [
  "fadeOut",
  "fadeOutDown",
  "fadeOutDownBig",
  "fadeOutUp",
  "fadeOutUpBig",
  "fadeOutLeft",
  "fadeOutLeftBig",
  "fadeOutRight",
  "fadeOutRightBi",
]