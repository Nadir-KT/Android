npm install redux;
npm install react-redux;